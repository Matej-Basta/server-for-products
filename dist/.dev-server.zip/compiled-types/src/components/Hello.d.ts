/// <reference types="react" />
declare const _default: () => import("react").JSX.Element;
export default _default;
