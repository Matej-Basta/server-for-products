/// <reference types="react" />
export default function Hello(): import("react").JSX.Element;
